# Cosmic's Marketplace — ADMIN PANEL (separate site)
# Run: python admin_app.py  ->  http://localhost:25571/cosmic/123/admin
# Reads/writes the SAME data.json / Photos / Vault folders as the main site.

import os
import time
import uuid
import requests
from datetime import datetime
from collections import defaultdict
from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, abort
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Pick a WRITABLE root (Pterodactyl: only the container dir is writable).
# Override with env var COSMIC_DATA_DIR if you want data somewhere specific.
def _pick_root():
    import tempfile
    candidates = [os.environ.get("COSMIC_DATA_DIR"), os.getcwd(), BASE_DIR,
                  os.path.dirname(BASE_DIR)]
    for cand in candidates:
        if cand and os.path.isdir(cand) and os.access(cand, os.W_OK):
            return cand
    return tempfile.gettempdir()
ROOT_DIR = _pick_root()

UPLOAD_FOLDER = os.path.join(ROOT_DIR, 'Photos')
VAULT_FOLDER = os.path.join(ROOT_DIR, 'Vault')
DATA_FILE = os.path.join(ROOT_DIR, 'data.json')

app = Flask(__name__)
app.secret_key = os.environ.get('COSMIC_ADMIN_SECRET', 'cosmic_admin_panel_secret')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['VAULT_FOLDER'] = VAULT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 200 * 1024 * 1024

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(VAULT_FOLDER, exist_ok=True)

# Where the storefront lives (used by "View Live Site" links / webhook URL fallback)
MAIN_SITE_URL = os.environ.get('MAIN_SITE_URL', 'http://localhost:25570')

# Default admin credentials — change these or set env vars before deploying!
ADMIN_USER = os.environ.get('ADMIN_USER', 'CosmicPrimee')
ADMIN_PASS = os.environ.get('ADMIN_PASS', 'Forbns123..')

request_history = defaultdict(list)
global_traffic = []


def load_data():
    if not os.path.exists(DATA_FILE):
        return {
            "profile": {"marketplace_name": "Cosmic's Marketplace", "owner_name": "", "bio": "", "roles": "", "contact_link": "t.me/CosmicPrimee"},
            "categories": [], "products": [], "users": [],
            "settings": {"gcash_name": "", "gcash_number": "", "gcash_qr": None,
                          "maya_name": "", "maya_number": "", "maya_qr": None,
                          "telegram_token": "", "telegram_id": "",
                          "legit_badge": True, "instant_delivery_badge": True,
                          "non_refund_policy": "All sales are final. No refunds."},
            "security": {"whitelist": [], "blocked_ips": [], "total_dropped": 0},
            "coin_requests": [], "invoices": [], "payouts": [], "shops": []
        }
    import json
    with open(DATA_FILE, 'r') as f:
        return json.load(f)


def save_data(data):
    import json
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)


def get_system_status():
    now = time.time()
    count = len([t for t in global_traffic if now - t < 60])
    if count > 3000:
        return "Under Attack"
    elif count > 1000:
        return "Recovering"
    return "Chilling"


@app.before_request
def track_traffic():
    global_traffic.append(time.time())
    global_traffic[:] = [t for t in global_traffic if time.time() - t < 60]


def admin_required(view_func):
    def wrapped(*args, **kwargs):
        if not session.get('admin'):
            return redirect(url_for('admin'))
        return view_func(*args, **kwargs)
    wrapped.__name__ = view_func.__name__
    return wrapped


# "View Live Site" link target — jumps to the storefront app
@app.route('/goto-marketplace')
def marketplace():
    return redirect(MAIN_SITE_URL)


@app.route('/cosmic/123/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'login':
            if request.form.get('username') == ADMIN_USER and request.form.get('password') == ADMIN_PASS:
                session['admin'] = True
                return redirect(url_for('admin'))
            return render_template('Admin.html', data=load_data(), logged_in=False,
                                   error="Invalid credentials", status=get_system_status())
        elif action == 'logout':
            session.pop('admin', None)
            return redirect(url_for('admin'))
    data = load_data()
    logged_in = session.get('admin', False)
    return render_template('Admin.html', data=data, logged_in=logged_in, status=get_system_status())


@app.route('/cosmic/123/admin/add_category', methods=['GET', 'POST'])
@admin_required
def add_category():
    name = request.form.get('category_name')
    photo = request.files.get('category_photo')
    photo_filename = None
    if photo and photo.filename != '':
        filename = secure_filename(photo.filename)
        photo_filename = f"{uuid.uuid4().hex}_{filename}"
        photo.save(os.path.join(app.config['UPLOAD_FOLDER'], photo_filename))
    data = load_data()
    data['categories'].append({'id': uuid.uuid4().hex, 'name': name, 'photo': photo_filename})
    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/edit_category/<category_id>', methods=['GET', 'POST'])
@admin_required
def edit_category(category_id):
    data = load_data()
    for cat in data['categories']:
        if cat['id'] == category_id:
            cat['name'] = request.form.get('category_name')
            photo = request.files.get('category_photo')
            if photo and photo.filename != '':
                if cat.get('photo') and os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'], cat['photo'])):
                    os.remove(os.path.join(app.config['UPLOAD_FOLDER'], cat['photo']))
                filename = secure_filename(photo.filename)
                photo_filename = f"{uuid.uuid4().hex}_{filename}"
                photo.save(os.path.join(app.config['UPLOAD_FOLDER'], photo_filename))
                cat['photo'] = photo_filename
            break
    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/delete_category/<category_id>', methods=['GET', 'POST'])
@admin_required
def delete_category(category_id):
    data = load_data()
    data['categories'] = [c for c in data['categories'] if c['id'] != category_id]
    for p in data['products']:
        if p['category_id'] == category_id:
            p['category_id'] = None
    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/add_product', methods=['GET', 'POST'])
@admin_required
def add_product():
    category_id = request.form.get('category_id')
    name = request.form.get('product_name')
    price = request.form.get('product_price')
    stock = int(request.form.get('stock', 0))
    description = request.form.get('product_description')
    payment_method = request.form.get('payment_method', 'contact_direct')
    main_photo = request.files.get('main_photo')
    gallery_photos = request.files.getlist('gallery_photos')
    product_file = request.files.get('product_file')

    main_photo_filename = None
    if main_photo and main_photo.filename != '':
        filename = secure_filename(main_photo.filename)
        main_photo_filename = f"{uuid.uuid4().hex}_{filename}"
        main_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], main_photo_filename))

    gallery_filenames = []
    for g_photo in gallery_photos:
        if g_photo and g_photo.filename != '':
            g_filename = secure_filename(g_photo.filename)
            unique_g_filename = f"{uuid.uuid4().hex}_{g_filename}"
            g_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], unique_g_filename))
            gallery_filenames.append(unique_g_filename)

    product_file_filename = None
    if product_file and product_file.filename != '':
        filename = secure_filename(product_file.filename)
        product_file_filename = f"vault_{uuid.uuid4().hex}_{filename}"
        product_file.save(os.path.join(app.config['VAULT_FOLDER'], product_file_filename))

    original_price = request.form.get('original_price', '').strip() or None
    bundle_note = request.form.get('bundle_note', '').strip()
    credentials = request.form.get('credentials', '').strip()
    low_stock_threshold = int(request.form.get('low_stock_threshold', 3) or 3)

    data = load_data()
    data['products'].append({
        'id': uuid.uuid4().hex,
        'category_id': category_id,
        'name': name,
        'price': price,
        'stock': stock,
        'description': description,
        'payment_method': payment_method,
        'main_photo': main_photo_filename,
        'gallery': gallery_filenames,
        'product_file': product_file_filename,
        'original_price': original_price,
        'bundle_note': bundle_note,
        'credentials': credentials,
        'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'reviews': [],
        'low_stock_threshold': low_stock_threshold
    })
    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/edit_product/<product_id>', methods=['GET', 'POST'])
@admin_required
def edit_product(product_id):
    data = load_data()
    for p in data['products']:
        if p['id'] == product_id:
            p['category_id'] = request.form.get('category_id')
            p['name'] = request.form.get('product_name')
            p['price'] = request.form.get('product_price')
            p['stock'] = int(request.form.get('stock', 0))
            p['description'] = request.form.get('product_description')
            p['payment_method'] = request.form.get('payment_method', 'contact_direct')
            p['original_price'] = request.form.get('original_price', '').strip() or None
            p['bundle_note'] = request.form.get('bundle_note', '').strip()
            p['credentials'] = request.form.get('credentials', '').strip()
            p['low_stock_threshold'] = int(request.form.get('low_stock_threshold', 3) or 3)

            main_photo = request.files.get('main_photo')
            if main_photo and main_photo.filename != '':
                filename = secure_filename(main_photo.filename)
                p['main_photo'] = f"{uuid.uuid4().hex}_{filename}"
                main_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], p['main_photo']))

            product_file = request.files.get('product_file')
            if product_file and product_file.filename != '':
                if p.get('product_file') and os.path.exists(os.path.join(app.config['VAULT_FOLDER'], p['product_file'])):
                    os.remove(os.path.join(app.config['VAULT_FOLDER'], p['product_file']))
                filename = secure_filename(product_file.filename)
                p['product_file'] = f"vault_{uuid.uuid4().hex}_{filename}"
                product_file.save(os.path.join(app.config['VAULT_FOLDER'], p['product_file']))
            break
    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/delete_product/<product_id>', methods=['GET', 'POST'])
@admin_required
def delete_product(product_id):
    data = load_data()
    data['products'] = [p for p in data['products'] if p['id'] != product_id]
    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/update_profile', methods=['GET', 'POST'])
@admin_required
def update_profile():
    data = load_data()
    data['profile'] = {
        'marketplace_name': request.form.get('marketplace_name'),
        'owner_name': request.form.get('owner_name'),
        'bio': request.form.get('bio'),
        'roles': request.form.get('roles'),
        'contact_link': request.form.get('contact_link')
    }
    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/update_settings', methods=['POST'])
@admin_required
def update_settings():
    data = load_data()
    s = data['settings']
    s['gcash_name'] = request.form.get('gcash_name')
    s['gcash_number'] = request.form.get('gcash_number')
    s['maya_name'] = request.form.get('maya_name')
    s['maya_number'] = request.form.get('maya_number')
    s['telegram_id'] = request.form.get('telegram_id')
    s['telegram_token'] = request.form.get('telegram_token')
    s['legit_badge'] = request.form.get('legit_badge') == 'on'
    s['instant_delivery_badge'] = request.form.get('instant_delivery_badge') == 'on'
    s['non_refund_policy'] = request.form.get('non_refund_policy', '').strip()

    qr_photo = request.files.get('gcash_qr')
    if qr_photo and qr_photo.filename != '':
        filename = secure_filename(qr_photo.filename)
        qr_filename = f"qr_{uuid.uuid4().hex}_{filename}"
        qr_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], qr_filename))
        s['gcash_qr'] = qr_filename

    maya_qr_photo = request.files.get('maya_qr')
    if maya_qr_photo and maya_qr_photo.filename != '':
        filename = secure_filename(maya_qr_photo.filename)
        qr_filename = f"qr_{uuid.uuid4().hex}_{filename}"
        maya_qr_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], qr_filename))
        s['maya_qr'] = qr_filename

    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/set_webhook', methods=['POST'])
@admin_required
def set_webhook():
    data = load_data()
    token = data['settings'].get('telegram_token')
    if token:
        host = request.headers.get('X-Forwarded-Host', request.headers.get('Host', request.host))
        webhook_url = f"https://{host}/webhook/telegram"
        url = f"https://api.telegram.org/bot{token}/setWebhook"
        try:
            res = requests.post(url, json={"url": webhook_url}, timeout=15)
            print(f"[ADMIN] Webhook Setup Attempt -> URL: {webhook_url} | Response: {res.text}")
        except Exception as e:
            print(f"[ADMIN] Webhook Setup Error: {e}")
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/security/add_whitelist', methods=['POST'])
@admin_required
def add_whitelist():
    ip = request.form.get('ip')
    if ip:
        data = load_data()
        if ip not in data['security']['whitelist']:
            data['security']['whitelist'].append(ip)
            save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/security/remove_whitelist/<ip>', methods=['POST'])
@admin_required
def remove_whitelist(ip):
    data = load_data()
    data['security']['whitelist'] = [i for i in data['security']['whitelist'] if i != ip]
    save_data(data)
    return redirect(url_for('admin'))


@app.route('/cosmic/123/admin/security/unblock/<ip>', methods=['POST'])
@admin_required
def unblock_ip(ip):
    data = load_data()
    data['security']['blocked_ips'] = [b for b in data['security']['blocked_ips'] if b['ip'] != ip]
    save_data(data)
    request_history.pop(ip, None)
    return redirect(url_for('admin'))


@app.route('/Photos/<path:filename>')
def serve_photos(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


if __name__ == '__main__':
    # PORT env: ginagamit ng hosting panels (Pterodactyl, Render, atbp.)
    app.run(host='0.0.0.0', port=int(os.environ.get('COSMIC_ADMIN_PORT', os.environ.get('PORT', 25571))), debug=False)
