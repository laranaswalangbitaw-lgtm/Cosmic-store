# main_site/app.py — Cosmic Marketplace (main storefront + tools)
# Run: python app.py  ->  http://localhost:25570
import os
import json
import uuid
import time
import requests
from datetime import datetime, timedelta
from collections import defaultdict
from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, abort, jsonify
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from markupsafe import escape, Markup

import tools_lib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Pick a WRITABLE root (Pterodactyl: only the container dir is writable).
# Override with env var COSMIC_DATA_DIR if you want data somewhere specific.
def _pick_root():
    import tempfile
    candidates = [os.environ.get("COSMIC_DATA_DIR"), os.getcwd(), BASE_DIR,
                  os.path.dirname(BASE_DIR)]
    for cand in candidates:
        if cand and os.path.isdir(cand) and os.access(cand, os.W_OK):
            return cand
    return tempfile.gettempdir()
ROOT_DIR = _pick_root()

app = Flask(__name__)
app.secret_key = os.environ.get('COSMIC_SECRET', 'cosmic_exclusive_marketplace_key')

UPLOAD_FOLDER = os.path.join(ROOT_DIR, 'Photos')
VAULT_FOLDER = os.path.join(ROOT_DIR, 'Vault')
DATA_FILE = os.path.join(ROOT_DIR, 'data.json')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['VAULT_FOLDER'] = VAULT_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(VAULT_FOLDER, exist_ok=True)

request_history = defaultdict(list)
global_traffic = []


def load_data():
    if not os.path.exists(DATA_FILE):
        return {
            "profile": {
                "marketplace_name": "Cosmic's Marketplace",
                "owner_name": "Cosmic",
                "bio": "Welcome to my exclusive marketplace.",
                "roles": "Owner / Admin",
                "contact_link": "t.me/CosmicPrimee"
            },
            "settings": {
                "gcash_name": "", "gcash_number": "", "gcash_qr": None,
                "maya_name": "", "maya_number": "", "maya_qr": None,
                "telegram_id": "", "telegram_token": "",
                "legit_badge": True, "instant_delivery_badge": True,
                "non_refund_policy": "Valid or No Money Back. Please double-check product details before purchasing."
            },
            "security": {"total_threats": 0, "total_dropped": 0, "whitelist": [], "blocked_ips": []},
            "categories": [], "products": [], "users": [], "coin_requests": [], "shops": []
        }
    with open(DATA_FILE, 'r') as f:
        data = json.load(f)
        defaults = {
            "security": {"total_threats": 0, "total_dropped": 0, "whitelist": [], "blocked_ips": []},
            "users": [], "settings": {"gcash_name": "", "gcash_number": "", "gcash_qr": None,
                                      "maya_name": "", "maya_number": "", "maya_qr": None,
                                      "telegram_id": "", "telegram_token": "", "legit_badge": True,
                                      "instant_delivery_badge": True,
                                      "non_refund_policy": "Valid or No Money Back. Please double-check product details before purchasing."},
            "coin_requests": [], "shops": [], "categories": [], "products": []
        }
        for k, v in defaults.items():
            if k not in data or not data[k]:
                if k in ("security", "settings"):
                    data.setdefault(k, {}).update({kk: vv for kk, vv in v.items() if kk not in data.get(k, {})})
                else:
                    data.setdefault(k, v)
        for u in data["users"]:
            u.setdefault("coins", 0)
            u.setdefault("invoices", [])
            u.setdefault("role", "buyer")
        for p in data["products"]:
            p.setdefault("payment_method", "contact_direct")
            p.setdefault("stock", 0)
            p.setdefault("product_file", None)
            p.setdefault("shop_id", None)
            p.setdefault("original_price", None)
            p.setdefault("bundle_note", "")
            p.setdefault("credentials", "")
            p.setdefault("created_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            p.setdefault("reviews", [])
            p.setdefault("low_stock_threshold", 3)

        # Park legacy products (no shop_id) under an auto-created Main shop
        orphan_products = [p for p in data["products"] if not p.get("shop_id")]
        if orphan_products:
            main_shop = next((s for s in data["shops"] if s.get("is_main")), None)
            if not main_shop:
                main_shop = {
                    "id": uuid.uuid4().hex, "owner_username": None,
                    "name": data.get("profile", {}).get("marketplace_name", "Main Shop"),
                    "slug": "main", "bio": "Original marketplace catalog.", "status": "active",
                    "is_main": True,
                    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "balance": 0, "commission_rate": 0
                }
                data["shops"].append(main_shop)
            for p in orphan_products:
                p["shop_id"] = main_shop["id"]
        return data


def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)


def enrich_products(products):
    """Attach computed display fields: discount_pct, is_new, avg_rating."""
    enriched = []
    for p in products:
        p = dict(p)
        p['discount_pct'] = 0
        try:
            op = int(''.join(ch for ch in str(p.get('original_price') or '') if ch.isdigit()))
            np_ = int(''.join(ch for ch in str(p.get('price') or '') if ch.isdigit()))
            if op > np_ > 0:
                p['discount_pct'] = int(round(100 - (np_ * 100 / op)))
        except Exception:
            pass
        p['is_new'] = False
        try:
            created = datetime.strptime(p.get('created_at', ''), "%Y-%m-%d %H:%M:%S")
            p['is_new'] = (datetime.now() - created) < timedelta(days=3)
        except Exception:
            pass
        reviews = p.get('reviews') or []
        p['avg_rating'] = round(sum(r.get('rating', 0) for r in reviews) / len(reviews), 1) if reviews else None
        p['review_count'] = len(reviews)
        enriched.append(p)
    return enriched


def get_shop(data, shop_id):
    return next((s for s in data.get("shops", []) if s["id"] == shop_id), None)


def get_shop_by_owner(data, username):
    return next((s for s in data.get("shops", []) if s.get("owner_username") == username), None)


def get_total_users():
    return len(load_data()['users'])


def current_user_context():
    current_user = session.get('user')
    coins = 0
    if current_user:
        data = load_data()
        u = next((u for u in data['users'] if u['username'] == current_user), None)
        if u:
            coins = u.get('coins', 0)
    return current_user, coins


@app.before_request
def axel_protection_middleware():
    client_ip = request.remote_addr
    data = load_data()
    now = time.time()

    if client_ip in data['security']['whitelist']:
        return

    blocked_entry = next((b for b in data['security']['blocked_ips'] if b['ip'] == client_ip), None)
    if blocked_entry:
        return render_template('Blocked.html', ref_id=blocked_entry['ref_id'])

    if not request.path.startswith('/Photos/'):
        request_history[client_ip] = [t for t in request_history[client_ip] if now - t < 60]
        request_history[client_ip].append(now)
        global_traffic.append(now)

        if len(request_history[client_ip]) > 1000:
            ref_id = uuid.uuid4().hex[:8].upper()
            data['security']['blocked_ips'].append({
                "ip": client_ip, "ref_id": ref_id, "signature": "Rate Limit Burst",
                "volume": len(request_history[client_ip]),
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            data['security']['total_threats'] += 1
            data['security']['total_dropped'] += len(request_history[client_ip])
            save_data(data)
            return render_template('Blocked.html', ref_id=ref_id)


@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data: blob:;"
    )
    return response


@app.template_filter('secure_description')
def secure_description(s):
    escaped_text = str(escape(s))
    return Markup(escaped_text.replace('\n', '<br>'))


# --- AJAX APIs ---
@app.route('/api/products')
def api_products():
    data = load_data()
    category_filter = request.args.get('category', 'all')
    products_to_show = data['products']
    if category_filter != 'all':
        products_to_show = [p for p in products_to_show if p['category_id'] == category_filter]

    products_to_show.sort(key=lambda x: int(x.get('stock', 0)) > 0, reverse=True)
    products_to_show = enrich_products(products_to_show)

    formatted_products = []
    for p in products_to_show:
        p_dict = p.copy()
        p_dict['photo_url'] = url_for('serve_photos', filename=p['main_photo']) if p.get('main_photo') else None
        cat = next((c for c in data['categories'] if c['id'] == p['category_id']), None)
        p_dict['category_name'] = cat['name'] if cat else ''
        p_dict['url'] = url_for('product', product_id=p['id'])
        formatted_products.append(p_dict)
    return jsonify({"products": formatted_products})


@app.route('/api/user_info')
def api_user_info():
    if 'user' not in session: return jsonify({"error": "Not logged in"}), 401
    data = load_data()
    user = next((u for u in data['users'] if u['username'] == session['user']), None)
    if not user: return jsonify({"error": "User not found"}), 404
    return jsonify({"coins": user.get('coins', 0), "invoices": user.get('invoices', [])})


@app.route('/api/buy_coins', methods=['POST'])
def api_buy_coins():
    if 'user' not in session: return jsonify({"error": "Not logged in"}), 401
    data = load_data()

    amount = request.form.get('amount')
    coins = int(request.form.get('coins', 0))
    photo = request.files.get('receipt')
    ref_number = request.form.get('ref_number', '').strip()
    pay_method = request.form.get('pay_method', 'gcash')

    if not photo or photo.filename == '':
        return jsonify({"error": "Receipt photo required"}), 400

    filename = secure_filename(photo.filename)
    photo_filename = f"req_{uuid.uuid4().hex}_{filename}"
    photo_path = os.path.join(app.config['UPLOAD_FOLDER'], photo_filename)
    photo.save(photo_path)

    req_id = uuid.uuid4().hex[:12]
    invoice_id = f"INV-{uuid.uuid4().hex[:8].upper()}"
    username = session['user']

    user = next((u for u in data['users'] if u['username'] == username), None)
    if not user:
        return jsonify({"error": "User not found"}), 404
    user['invoices'].insert(0, {
        "id": invoice_id, "type": "Coin Purchase",
        "description": f"{amount} for {coins} Coins ({pay_method.upper()}{', Ref# ' + ref_number if ref_number else ''})",
        "status": "Pending", "date": datetime.now().strftime("%Y-%m-%d %H:%M")
    })

    data['coin_requests'].append({
        "id": req_id, "invoice_id": invoice_id, "username": username,
        "amount": amount, "coins": coins, "pay_method": pay_method,
        "ref_number": ref_number, "status": "Pending"
    })
    save_data(data)

    tg_token = data['settings'].get('telegram_token')
    tg_id = data['settings'].get('telegram_id')
    if tg_token and tg_id:
        url = f"https://api.telegram.org/bot{tg_token}/sendPhoto"
        caption = (f"• Method: {pay_method.upper()}\n• Worth: {amount}\n• Coin Requested: {coins}\n"
                   f"• Ref#: {ref_number or 'N/A'}\n• Username: {username}")
        reply_markup = {"inline_keyboard": [[
            {"text": "✅ Approve", "callback_data": f"approve_{req_id}"},
            {"text": "❌ Decline", "callback_data": f"decline_{req_id}"}
        ]]}
        try:
            with open(photo_path, 'rb') as f:
                requests.post(url, data={'chat_id': tg_id, 'caption': caption,
                                        'reply_markup': json.dumps(reply_markup)},
                              files={'photo': f}, timeout=10)
        except Exception:
            pass
    return jsonify({"success": True})


@app.route('/api/buy_product', methods=['POST'])
def api_buy_product():
    if 'user' not in session: return jsonify({"error": "Not logged in"}), 401
    product_id = request.form.get('product_id')
    data = load_data()

    product = next((p for p in data['products'] if p['id'] == product_id), None)
    if not product: return jsonify({"error": "Product not found"}), 404
    if product.get('payment_method') != 'coin_system': return jsonify({"error": "Not a coin system product"}), 400
    if int(product.get('stock', 0)) <= 0:
        return jsonify({"error": "This product is out of stock"}), 400

    price_val = 0
    try:
        price_val = int(product['price'].split()[0])
    except Exception:
        return jsonify({"error": "Invalid product price configuration"}), 400

    user = next((u for u in data['users'] if u['username'] == session['user']), None)
    if user['coins'] < price_val:
        return jsonify({"error": "Insufficient coins"}), 400

    user['coins'] -= price_val
    product['stock'] = int(product['stock']) - 1
    receipt_id = f"REC-{uuid.uuid4().hex[:12].upper()}"

    # Credit the owning shop, minus platform commission
    shop = get_shop(data, product.get('shop_id'))
    if shop and not shop.get('is_main'):
        commission_rate = shop.get('commission_rate', 10)
        shop_cut = price_val - (price_val * commission_rate // 100)
        shop['balance'] = shop.get('balance', 0) + shop_cut

    user['invoices'].insert(0, {
        "id": receipt_id, "type": "Product Purchase",
        "description": product['name'], "status": "Paid",
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "file": product.get('product_file'),
        "shop_id": product.get('shop_id'),
        "product_id": product.get('id'),
        "credentials": product.get('credentials')
    })
    save_data(data)

    tg_token = data['settings'].get('telegram_token')
    tg_id = data['settings'].get('telegram_id')
    if tg_token and tg_id:
        url = f"https://api.telegram.org/bot{tg_token}/sendMessage"
        msg = (f"🛒 **New Product Purchase**\n\n• Product: {product['name']}\n"
               f"• Buyer: {user['username']}\n• Stock Remaining: {product['stock']}\n"
               f"• Unique Receipt: `{receipt_id}`")
        try:
            requests.post(url, json={'chat_id': tg_id, 'text': msg, 'parse_mode': 'Markdown'}, timeout=10)
        except Exception:
            pass
    return jsonify({"success": True, "receipt_id": receipt_id, "credentials": product.get('credentials') or None})


@app.route('/api/submit_review', methods=['POST'])
def submit_review():
    if 'user' not in session: return jsonify({"error": "Not logged in"}), 401
    data = load_data()
    username = session['user']
    product_id = request.form.get('product_id')
    rating = max(1, min(5, int(request.form.get('rating', 5))))
    comment = escape(request.form.get('comment', '').strip())[:500]

    user = next((u for u in data['users'] if u['username'] == username), None)
    product = next((p for p in data['products'] if p['id'] == product_id), None)
    if not user or not product: return jsonify({"error": "Not found"}), 404

    bought = any(i.get('product_id') == product_id and i.get('status') == 'Paid' for i in user.get('invoices', []))
    if not bought:
        return jsonify({"error": "Only buyers who purchased this item can leave a review"}), 403
    if any(r.get('username') == username for r in product.get('reviews', [])):
        return jsonify({"error": "You already reviewed this product"}), 400

    product.setdefault('reviews', []).insert(0, {
        "username": username, "rating": rating, "comment": str(comment),
        "date": datetime.now().strftime("%Y-%m-%d %H:%M")
    })
    save_data(data)
    return jsonify({"success": True})


# --- TOOLS API (usable inside the website) ---
@app.route('/tools')
def tools_page():
    current_user, coins = current_user_context()
    return render_template('Tools.html', data=load_data(), current_user=current_user, coins=coins)


@app.route('/api/tools/url_remover', methods=['POST'])
def tool_url_remover():
    text = request.form.get('text', '')
    if not text.strip():
        return jsonify({"error": "Paste some text first"}), 400
    result = tools_lib.URLRemoverTool().remove_urls(text)
    return jsonify(result)


@app.route('/api/tools/encryptor', methods=['POST'])
def tool_encryptor():
    code = request.form.get('code', '')
    try:
        option = int(request.form.get('option', 1))
    except ValueError:
        option = 1
    if not code.strip():
        return jsonify({"error": "Paste some Python code first"}), 400
    encoded = tools_lib.encode_file(code, option)
    return jsonify({"success": not encoded.startswith("# Encoding Error"),
                    "option": tools_lib.ENCODING_OPTIONS.get(option, ("Unknown",))[0],
                    "encoded": encoded})


@app.route('/api/tools/proxy_scraper', methods=['POST'])
def tool_proxy_scraper():
    result = tools_lib.ProxyScraperTool().scrape_and_validate()
    return jsonify(result)


@app.route('/api/tools/dev_id', methods=['POST'])
def tool_dev_id():
    device_ids = [d.strip() for d in request.form.get('device_ids', '').replace('\n', ',').split(',') if d.strip()]
    if not device_ids:
        return jsonify({"error": "Enter at least one Device ID"}), 400
    tool = tools_lib.DevIdCheckerTool()
    result = tool.check_bulk_devices(device_ids[:20])
    return jsonify(result)


# --- Shop storefront & vault ---
@app.route('/shop/<slug>')
def shop_storefront(slug):
    data = load_data()
    shop = next((s for s in data['shops'] if s['slug'] == slug), None)
    if not shop: return "Shop not found", 404
    shop_products = sorted([p for p in data['products'] if p.get('shop_id') == shop['id']],
                           key=lambda x: int(x.get('stock', 0)) > 0, reverse=True)
    shop_products = enrich_products(shop_products)
    current_user, coins = current_user_context()
    return render_template('Marketplace.html', data=data, products=shop_products, active_category='all',
                           current_user=current_user, coins=coins, users_count=get_total_users(),
                           viewing_shop=shop)


@app.route('/vault/download/<filename>')
def download_vault_file(filename):
    if 'user' not in session: return abort(401)
    data = load_data()
    user = next((u for u in data['users'] if u['username'] == session['user']), None)
    if not user: return abort(401)

    owns_file = any(inv.get('file') == filename and inv.get('status') == 'Paid' for inv in user.get('invoices', []))
    if not owns_file:
        return abort(403)
    return send_from_directory(app.config['VAULT_FOLDER'], filename, as_attachment=True)


# --- Telegram webhook (coin approve/decline buttons) ---
@app.route('/webhook/telegram', methods=['POST'])
def telegram_webhook():
    try:
        update = request.get_json(force=True, silent=True)
        if not update:
            return 'OK', 200

        if 'callback_query' in update:
            cb = update['callback_query']
            data_str = cb.get('data', '')
            cb_id = cb.get('id')

            data = load_data()
            tg_token = data['settings'].get('telegram_token')

            if data_str.startswith(('approve_', 'decline_')):
                action, req_id = data_str.split('_', 1)
                req = next((r for r in data['coin_requests'] if r['id'] == req_id), None)

                if req and req['status'] == 'Pending':
                    user = next((u for u in data['users'] if u['username'] == req['username']), None)
                    if action == 'approve':
                        req['status'] = 'Approved'
                        if user:
                            user['coins'] += req['coins']
                            inv = next((i for i in user['invoices'] if i['id'] == req['invoice_id']), None)
                            if inv: inv['status'] = 'Paid'
                        text_addon = "\n\n✅ STATUS: APPROVED"
                    else:
                        req['status'] = 'Cancelled'
                        if user:
                            inv = next((i for i in user['invoices'] if i['id'] == req['invoice_id']), None)
                            if inv: inv['status'] = 'Cancelled'
                        text_addon = "\n\n❌ STATUS: CANCELLED"

                    save_data(data)

                    if tg_token and 'message' in cb:
                        chat_id = cb['message']['chat']['id']
                        message_id = cb['message']['message_id']
                        original_caption = cb['message'].get('caption') or ''
                        try:
                            requests.post(f"https://api.telegram.org/bot{tg_token}/editMessageCaption", json={
                                'chat_id': chat_id, 'message_id': message_id,
                                'caption': original_caption + text_addon,
                                'reply_markup': {'inline_keyboard': []}
                            }, timeout=5)
                        except Exception as e:
                            print("[SYSTEM] Error editing Telegram message:", e)

            if tg_token and cb_id:
                try:
                    requests.post(f"https://api.telegram.org/bot{tg_token}/answerCallbackQuery", json={
                        'callback_query_id': cb_id, 'text': "Action Processed!"
                    }, timeout=5)
                except Exception as e:
                    print("[SYSTEM] Error answering callback query:", e)
    except Exception as e:
        print(f"[SYSTEM] General webhook error: {e}")
    return 'OK', 200


# --- Frontend routes ---
@app.route('/')
def marketplace():
    data = load_data()
    all_products = sorted(data['products'], key=lambda x: int(x.get('stock', 0)) > 0, reverse=True)
    all_products = enrich_products(all_products)
    current_user, coins = current_user_context()
    return render_template('Marketplace.html', data=data, products=all_products, active_category='all',
                           current_user=current_user, coins=coins, users_count=get_total_users())


@app.route('/product/<product_id>')
def product(product_id):
    data = load_data()
    selected_product = next((p for p in data['products'] if p['id'] == product_id), None)
    if not selected_product: return "Product not found", 404
    selected_product = enrich_products([selected_product])[0]
    current_user, coins = current_user_context()
    return render_template('Product.html', data=data, product=selected_product,
                           current_user=current_user, coins=coins, users_count=get_total_users())


@app.route('/buy_coins')
def buy_coins():
    if 'user' not in session: return redirect(url_for('user_login'))
    data = load_data()
    current_user, coins = current_user_context()
    return render_template('BuyCoins.html', data=data, current_user=current_user, coins=coins,
                           users_count=get_total_users())


@app.route('/invoices')
def invoices():
    if 'user' not in session: return redirect(url_for('user_login'))
    data = load_data()
    current_user, coins = current_user_context()
    user_data = next((u for u in data['users'] if u['username'] == current_user), None)
    invoices_list = user_data.get('invoices', []) if user_data else []
    return render_template('Invoices.html', data=data, current_user=current_user, coins=coins,
                           invoices=invoices_list, users_count=get_total_users())


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        username = request.form.get('username')
        password = request.form.get('password')
        repeat_password = request.form.get('repeat_password')

        allowed_domains = ['@gmail.com', '@outlook.com', '@yahoo.com']
        if not any(email.lower().endswith(domain) for domain in allowed_domains):
            return render_template('Register.html', data=load_data(), error="Invalid email provider.")
        if password != repeat_password:
            return render_template('Register.html', data=load_data(), error="Passwords do not match.")

        data = load_data()
        if any(u['username'].lower() == username.lower() for u in data['users']):
            return render_template('Register.html', data=load_data(), error="Username is already taken.")
        if any(u['email'].lower() == email.lower() for u in data['users']):
            return render_template('Register.html', data=load_data(), error="Email is already registered.")

        data['users'].append({
            'id': uuid.uuid4().hex, 'email': email, 'username': username,
            'password': generate_password_hash(password),
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'coins': 0, 'invoices': []
        })
        save_data(data)
        return redirect(url_for('user_login'))
    return render_template('Register.html', data=load_data())


@app.route('/login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        data = load_data()
        user = next((u for u in data['users'] if u['username'].lower() == username.lower()), None)
        if user and check_password_hash(user['password'], password):
            session['user'] = user['username']
            return redirect(url_for('marketplace'))
        return render_template('Login.html', data=load_data(), error="Invalid username or password.")
    return render_template('Login.html', data=load_data())


@app.route('/logout')
def user_logout():
    session.pop('user', None)
    return redirect(url_for('marketplace'))


# --- Seller / Shop routes ---
def shop_owner_required(view_func):
    def wrapped(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('user_login'))
        data = load_data()
        shop = get_shop_by_owner(data, session['user'])
        if not shop or shop.get('status') != 'active':
            return redirect(url_for('shop_apply'))
        return view_func(shop, data, *args, **kwargs)
    wrapped.__name__ = view_func.__name__
    return wrapped


@app.route('/shop/apply', methods=['GET', 'POST'])
def shop_apply():
    if 'user' not in session:
        return redirect(url_for('user_login'))
    data = load_data()
    existing = get_shop_by_owner(data, session['user'])

    if request.method == 'POST':
        if existing:
            return redirect(url_for('dashboard'))
        shop_name = request.form.get('shop_name', '').strip()
        bio = request.form.get('bio', '').strip()
        slug = secure_filename(shop_name.lower().replace(' ', '-')) or uuid.uuid4().hex[:8]

        if not shop_name:
            return render_template('ShopApply.html', data=data, error="Shop name is required.")
        if any(s['slug'] == slug for s in data['shops']):
            slug = f"{slug}-{uuid.uuid4().hex[:4]}"

        data['shops'].append({
            "id": uuid.uuid4().hex, "owner_username": session['user'],
            "name": shop_name, "slug": slug, "bio": bio, "status": "active",
            "is_main": False,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "balance": 0, "commission_rate": 10
        })
        for u in data['users']:
            if u['username'] == session['user']:
                u['role'] = 'seller'
                break
        save_data(data)
        return redirect(url_for('dashboard'))

    return render_template('ShopApply.html', data=data, existing_shop=existing)


@app.route('/dashboard')
@shop_owner_required
def dashboard(shop, data):
    shop_products = [p for p in data['products'] if p.get('shop_id') == shop['id']]

    commission_rate = shop.get('commission_rate', 10)
    for p in shop_products:
        try:
            price_val = int(''.join(ch for ch in str(p.get('price') or '') if ch.isdigit()))
            p['net_cut'] = price_val - (price_val * commission_rate // 100)
        except Exception:
            p['net_cut'] = '—'

    total_sold = 0
    gross_sales = 0
    for u in data['users']:
        for inv in u.get('invoices', []):
            if inv.get('shop_id') == shop['id'] and inv.get('status') == 'Paid':
                total_sold += 1
                p = next((x for x in shop_products if x['id'] == inv.get('product_id')), None)
                if p:
                    try:
                        gross_sales += int(str(p['price']).split()[0])
                    except Exception:
                        pass

    shop_link = url_for('shop_storefront', slug=shop['slug'], _external=True)
    return render_template('Dashboard.html', data=data, shop=shop, products=shop_products,
                           categories=data['categories'], commission_rate=commission_rate,
                           total_sold=total_sold, gross_sales=gross_sales, shop_link=shop_link)


@app.route('/dashboard/add_product', methods=['POST'])
@shop_owner_required
def dashboard_add_product(shop, data):
    category_id = request.form.get('category_id')
    name = request.form.get('product_name')
    price = request.form.get('product_price')
    stock = int(request.form.get('stock', 0))
    description = request.form.get('product_description')
    payment_method = request.form.get('payment_method', 'contact_direct')
    main_photo = request.files.get('main_photo')
    product_file = request.files.get('product_file')
    original_price = request.form.get('original_price', '').strip() or None
    bundle_note = request.form.get('bundle_note', '').strip()
    credentials = request.form.get('credentials', '').strip()
    low_stock_threshold = int(request.form.get('low_stock_threshold', 3) or 3)

    main_photo_filename = None
    if main_photo and main_photo.filename != '':
        filename = secure_filename(main_photo.filename)
        main_photo_filename = f"{uuid.uuid4().hex}_{filename}"
        main_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], main_photo_filename))

    product_file_filename = None
    if product_file and product_file.filename != '':
        filename = secure_filename(product_file.filename)
        product_file_filename = f"vault_{uuid.uuid4().hex}_{filename}"
        product_file.save(os.path.join(app.config['VAULT_FOLDER'], product_file_filename))

    data['products'].append({
        'id': uuid.uuid4().hex, 'shop_id': shop['id'], 'category_id': category_id,
        'name': name, 'price': price, 'stock': stock, 'description': description,
        'payment_method': payment_method, 'main_photo': main_photo_filename, 'gallery': [],
        'product_file': product_file_filename, 'original_price': original_price,
        'bundle_note': bundle_note, 'credentials': credentials,
        'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'reviews': [], 'low_stock_threshold': low_stock_threshold
    })
    save_data(data)
    return redirect(url_for('dashboard'))


@app.route('/dashboard/edit_product/<product_id>', methods=['POST'])
@shop_owner_required
def dashboard_edit_product(shop, data, product_id):
    for p in data['products']:
        if p['id'] == product_id and p.get('shop_id') == shop['id']:
            p['category_id'] = request.form.get('category_id')
            p['name'] = request.form.get('product_name')
            p['price'] = request.form.get('product_price')
            p['stock'] = int(request.form.get('stock', 0))
            p['description'] = request.form.get('product_description')
            p['payment_method'] = request.form.get('payment_method', 'contact_direct')
            p['original_price'] = request.form.get('original_price', '').strip() or None
            p['bundle_note'] = request.form.get('bundle_note', '').strip()
            p['credentials'] = request.form.get('credentials', '').strip()
            p['low_stock_threshold'] = int(request.form.get('low_stock_threshold', 3) or 3)
            break
    save_data(data)
    return redirect(url_for('dashboard'))


@app.route('/dashboard/delete_product/<product_id>', methods=['POST'])
@shop_owner_required
def dashboard_delete_product(shop, data, product_id):
    data['products'] = [p for p in data['products'] if not (p['id'] == product_id and p.get('shop_id') == shop['id'])]
    save_data(data)
    return redirect(url_for('dashboard'))


@app.route('/dashboard/payout/request', methods=['POST'])
@shop_owner_required
def dashboard_request_payout(shop, data):
    amount = int(request.form.get('amount', 0))
    if amount <= 0 or amount > shop.get('balance', 0):
        return redirect(url_for('dashboard'))
    data.setdefault('payout_requests', []).append({
        "id": uuid.uuid4().hex[:12], "shop_id": shop['id'], "shop_name": shop['name'],
        "amount": amount, "status": "Pending",
        "date": datetime.now().strftime("%Y-%m-%d %H:%M")
    })
    shop['balance'] -= amount
    save_data(data)
    return redirect(url_for('dashboard'))


@app.route('/Photos/<path:filename>')
def serve_photos(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


if __name__ == '__main__':
    # PORT env: ginagamit ng hosting panels (Pterodactyl, Render, atbp.)
    app.run(host='0.0.0.0', port=int(os.environ.get('COSMIC_MAIN_PORT', os.environ.get('PORT', 25570))), debug=False)
