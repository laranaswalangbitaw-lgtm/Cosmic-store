# main_site/tools_lib.py — Tool backends used by the /tools page (all run server-side)
import re
import json
import zlib
import gzip
import lzma
import base64
import marshal
import random
import requests
from typing import Dict, List, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed


# ---------------------------------------------------------------- URL Remover
class URLRemoverTool:
    """Remove URLs / emails / shortlinks from text while preserving formatting."""
    TOOL_NAME = "URL Remover"
    TOOL_ID = "url_remover"

    PATTERNS = {
        "http": r'https?://(?:www\.)?[\w/\-\.~?=&%#]+',
        "ftp": r'ftp://[\w/\-\.~?=&%#]+',
        "www": r'(?:www\.)?[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]{2,}(?:/[\w/\-\.~?=&%#]*)?',
        "email": r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        "shortlink": r'bit\.ly/[\w]+|tinyurl\.com/[\w]+|short\.link/[\w]+',
    }

    def __init__(self):
        self.compiled = {name: re.compile(pattern) for name, pattern in self.PATTERNS.items()}

    def remove_urls(self, text: str) -> Dict:
        original_length = len(text)
        processed = text
        removed_urls = []
        for pattern in self.compiled.values():
            matches = pattern.findall(processed)
            removed_urls.extend(matches)
            processed = pattern.sub('', processed)
        processed = re.sub(r'\s+', ' ', processed).strip()
        return {
            "success": True,
            "original_length": original_length,
            "processed_length": len(processed),
            "urls_removed": len(set(removed_urls)),
            "removed_urls": list(set(removed_urls))[:20],
            "processed_text": processed
        }


# ---------------------------------------------------------------- Encryptor
zlb = lambda in_: zlib.compress(in_)
b16 = lambda in_: base64.b16encode(in_)
b32 = lambda in_: base64.b32encode(in_)
b64 = lambda in_: base64.b64encode(in_)
gzi = lambda in_: gzip.compress(in_)
lzm = lambda in_: lzma.compress(in_)
mar = lambda in_: marshal.dumps(compile(in_, '<x>', 'exec'))

ENCODING_OPTIONS = {
    1: ("Marshal", "mar(data.encode('utf8'))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('marshal').loads(__[::-1]);"),
    2: ("Zlib", "zlb(data.encode('utf8'))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('zlib').decompress(__[::-1]);"),
    3: ("Base16", "b16(data.encode('utf8'))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('base64').b16decode(__[::-1]);"),
    4: ("Base32", "b32(data.encode('utf8'))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('base64').b32decode(__[::-1]);"),
    5: ("Base64", "b64(data.encode('utf8'))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('base64').b64decode(__[::-1]);"),
    6: ("Lzma", "lzm(data.encode('utf8'))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('lzma').decompress(__[::-1]);"),
    7: ("Gzip", "gzi(data.encode('utf8'))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('gzip').decompress(__[::-1]);"),
    8: ("Zlib+B16", "b16(zlb(data.encode('utf8')))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('zlib').decompress(__import__('base64').b16decode(__[::-1]));"),
    9: ("Zlib+B32", "b32(zlb(data.encode('utf8')))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('zlib').decompress(__import__('base64').b32decode(__[::-1]));"),
    10: ("Zlib+B64", "b64(zlb(data.encode('utf8')))[::-1]", "# Encoded By Cosmic Encryptor\n\n_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));"),
}


def encode_file(code_data: str, option: int = 1) -> str:
    """Encode Python source with the selected method (for protecting your own scripts)."""
    if option not in ENCODING_OPTIONS:
        option = 1
    _, xx, heading = ENCODING_OPTIONS[option]
    try:
        encoded = eval(xx, {"data": code_data, "mar": mar, "zlb": zlb, "b16": b16,
                            "b32": b32, "b64": b64, "gzi": gzi, "lzm": lzm})
        return heading + f"exec((_)({repr(encoded)}))"
    except SyntaxError as e:
        return f"# Encoding Error: invalid Python syntax -> {e}"
    except Exception as e:
        return f"# Encoding Error: {str(e)}"


# ---------------------------------------------------------------- Proxy Scraper
class ProxyScraperTool:
    """Multi-source free proxy scraper with validation."""
    TOOL_NAME = "Proxy Scraper"
    TOOL_ID = "proxy_scraper"

    SOURCES = {
        "free_proxy_list": "https://www.proxy-list.download/api/v1/get?type=http",
        "socks_proxy": "https://www.socks-proxy.net/",
        "ssl_proxies": "https://www.sslproxies.org/",
    }

    def __init__(self):
        self.found_proxies = []
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})

    def _scrape_from_source(self, url: str) -> List[str]:
        try:
            response = self.session.get(url, timeout=15.0)
            if response.status_code != 200:
                return []
            return list(set(re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}:\d{2,5}\b', response.text)))
        except Exception:
            return []

    def _validate_proxy(self, proxy: str) -> bool:
        try:
            proxy_dict = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
            response = self.session.get("https://httpbin.org/ip", proxies=proxy_dict, timeout=5.0)
            return response.status_code == 200
        except Exception:
            return False

    def scrape_and_validate(self) -> Dict:
        self.found_proxies = []
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = {executor.submit(self._scrape_from_source, url): url for url in self.SOURCES.values()}
            for future in as_completed(futures):
                try:
                    proxies = future.result()
                    if isinstance(proxies, list):
                        self.found_proxies.extend(proxies)
                except Exception:
                    pass

        self.found_proxies = list(set(self.found_proxies))
        test_list = self.found_proxies[:30]
        valid_proxies = []

        if test_list:
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = {executor.submit(self._validate_proxy, proxy): proxy for proxy in test_list}
                for future in as_completed(futures):
                    try:
                        if future.result():
                            valid_proxies.append(futures[future])
                    except Exception:
                        pass

        return {
            "success": True,
            "total_found": len(self.found_proxies),
            "tested": len(test_list),
            "valid": len(valid_proxies),
            "success_rate": f"{(len(valid_proxies) / max(len(test_list), 1)) * 100:.1f}%",
            "proxies": valid_proxies
        }


# ---------------------------------------------------------------- MLBB Dev ID Checker
class DevIdCheckerTool:
    """Mobile Legends Device ID lookup — used by sellers to show account info (rank, WR, etc.)."""
    TOOL_NAME = "MLBB Dev ID Checker"
    TOOL_ID = "dev_id_checker"
    MLBB_API = "https://m.mobilelegends.com"

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "Mozilla/5.0 (Linux; Android 10)"})

    def check_device_id(self, device_id: str) -> Dict:
        try:
            response = self.session.get(
                f"{self.MLBB_API}/api/device/check",
                params={"device_id": device_id},
                headers={"X-Device-ID": device_id, "Accept": "application/json"},
                timeout=15.0
            )
            if response.status_code == 200:
                data = response.json()
                return {
                    "success": True, "device_id": device_id, "status": "active",
                    "username": data.get("username", "Unknown"),
                    "level": data.get("level", "N/A"),
                    "rank": data.get("rank", "Warrior"),
                    "role": data.get("role", "No main role"),
                    "wr": data.get("wr", "N/A"),
                    "heroes": data.get("heroes_count", 0),
                    "matches": data.get("matches", 0),
                    "account_age": data.get("age_days", "Unknown"),
                    "v2l": "Yes" if data.get("v2l", False) else "No",
                }
            elif response.status_code == 404:
                return {"success": False, "device_id": device_id, "error": "Device ID not found"}
            return {"success": False, "device_id": device_id, "error": f"API error {response.status_code}"}
        except requests.exceptions.Timeout:
            return {"success": False, "device_id": device_id, "error": "Request timeout"}
        except requests.exceptions.ConnectionError:
            return {"success": False, "device_id": device_id, "error": "Connection error"}
        except Exception as e:
            return {"success": False, "device_id": device_id, "error": str(e)[:80]}

    def check_bulk_devices(self, device_ids: list) -> Dict:
        results = []
        with ThreadPoolExecutor(max_workers=min(10, len(device_ids))) as executor:
            futures = {executor.submit(self.check_device_id, did): did for did in device_ids}
            for future in as_completed(futures):
                results.append(future.result())

        valid = [r for r in results if r.get("success")]
        return {
            "success": True, "total": len(device_ids),
            "valid_count": len(valid), "invalid_count": len(results) - len(valid),
            "results": results,
            "summary": {"valid": len(valid), "invalid": len(results) - len(valid),
                        "success_rate": f"{(len(valid) / max(len(device_ids), 1)) * 100:.1f}%"}
        }
