# Cosmic's Marketplace — Yellow + Cyan + Black

Main site + hiwalay na admin panel, iisang data.json.

## Layout (upload as-is sa server root)
app.py, tools_lib.py, static/logos/, templates/, admin_site/, requirements.txt

## Run
pip install -r requirements.txt
python app.py                    # main site (PORT env o 25570)
python admin_site/admin_app.py    # admin (ADMIN: /cosmic/123/admin)

Admin login: CosmicPrimee / Forbns123.. — palitan agad (admin_site/admin_app.py o env ADMIN_USER/ADMIN_PASS).
