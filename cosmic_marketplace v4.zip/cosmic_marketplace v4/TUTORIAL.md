# 🛠️ COSMIC'S MARKETPLACE — FULL TUTORIAL (Tuts)

Theme: **Yellow + Cyan + Black**. Logo naka-place sa nav, sidebar, login pages, admin panel, at favicon.

## File layout (EXACT — para walang error sa hosting)

I-upload lahat ng files KUNG ano ang pangalan, direcho sa server root (yung folder na makikita sa file manager):

```
/app.py                       <- main site (nasa root na, hindi nasa folder)
/tools_lib.py
/static/logos/logo.svg
/static/logos/icon.svg
/templates/Marketplace.html
/templates/Product.html
/templates/Tools.html
/templates/BuyCoins.html
/templates/Invoices.html
/templates/Login.html
/templates/Register.html
/templates/Dashboard.html
/templates/ShopApply.html
/templates/Blocked.html
/admin_site/admin_app.py
/admin_site/static/logo.svg
/admin_site/templates/Admin.html
/requirements.txt
```

Walang kailangang i-create pa — gagawa lang ang app ng `data.json`, `Photos/`, at `Vault/` sa root pag unang run.

## 1. Install (one time)

Python 3.9+ ang kailangan.

```
pip install -r requirements.txt
```

## 2. Pag-run

**Main site:**
```
python app.py
```
- Local: http://localhost:25570
- Sa hosting: automatic gagamitin ang PORT env ng panel. Bukas ang URL ng server mo.

**Admin panel (hiwalay na site — ibang server o ibang terminal):**
```
python admin_site/admin_app.py
```
- Local: http://localhost:25571/cosmic/123/admin

> Parehong nagbabasa/nagsusulat sa iisang `data.json`, `Photos/`, `Vault` sa root. Kung hiwalay na server ang admin, i-copy ang data files sa parehong lugar o i-set ang env `COSMIC_DATA_DIR`.

## 3. Admin Panel

- **Login:** `CosmicPrimee` / `Forbns123..`
- **Palitan agad ang credentials:** admin_site/admin_app.py — hanapin `ADMIN_USER` / `ADMIN_PASS`, o i-set as env vars.

**Tabs:** Categories (add/edit/delete + image), Products (category, payment method, stock, price, sale price, low-stock threshold, bundle note, credentials, description, images, gallery, digital file → Vault), Security (whitelist, unblock, threat log), Profile (marketplace name, owner, bio, roles, contact), Settings (GCash/Maya + QR, Telegram token + ID, badges, non-refund policy, webhook deploy button).

## 4. Coin System Flow

1. Admin: Settings → GCash/Maya details + QR.
2. User: Register → Buy Coins → package (50/100/150/200, custom min 250) → GCash/Maya → receipt upload + ref number.
3. Admin: approve sa Telegram bot (Approve/Decline buttons) → automatic credited.
4. User: buy Coin System product → instant delivery: credentials/file sa screen + Invoices tab.

## 5. Telegram Bot (optional)

1. Gawa bot kay @BotFather → kopya token.
2. I-message ang bot, kunin user ID (@userinfobot).
3. Admin → Settings → Bot Token + Admin Telegram ID → Save.
4. Click **Execute Webhook Setup** (gawin ulit pag nagpalit ng token/URL).

## 6. Free Tools (sa loob ng site)

Marketplace → Menu → **Free Tools** (o /tools):

| Tool | Gamit |
|------|------|
| URL Remover | Tatanggalin ang tracking params sa URL |
| Python Encryptor | 10 encoding modes (Base64, Hex, ROT13, Binary, atbp.) |
| Proxy Scraper | Fresh public proxies (http/https/socks) |
| MLBB Dev ID Checker | Check kung valid ang MLBB dev ID |

## 7. Palitan ang Logo

- Files: `static/logos/logo.svg` at `icon.svg` (main), `admin_site/static/logo.svg` (admin).
- Pwedeng palitan ng sariling PNG — parehong filename lang, o i-edit ang <img src> sa templates.
- Marketplace name: Admin → Profile.

## 8. Palitan ang Kulay

Tailwind classes sa templates:
- Yellow primary: `bg-yellow-400`, `hover:bg-yellow-300`, `rgba(250,204,21,...)`
- Cyan secondary: `text-cyan-400`, `border-cyan-900`, `bg-cyan-950/40`
- Black bg: `#030303`

## 9. Hosting (Pterodactyl atbp.)

- Read-only ang filesystem maliban sa server folder — kaya pumipili na ang app ng writable folder (cwd muna). Override via env `COSMIC_DATA_DIR`.
- PORT env ang sinusunod ng app (Pterodactyl/Render style). `COSMIC_MAIN_PORT` / `COSMIC_ADMIN_PORT` para i-override.
- Kailangan: Python 3.9+ server type, 256MB+ memory.
- `/webhook/telegram` ay nasa main site — ituro ang webhook sa main domain (HTTPS).

## 10. Troubleshooting

- **500/blank** — tignan kung nasa root ang app.py at templates/ (hindi nasa subfolder).
- **Hindi lalabas photos** — nasa `Photos/` dapat, tama ang filename.
- **Admin ayaw pasukin** — `ADMIN_USER`/`ADMIN_PASS` sa admin_site/admin_app.py.
- **Port error sa hosting** — dapat ginagamit ng panel ang PORT env; susunod na ang app.
